from __future__ import annotations

import json
import os
import re
from datetime import datetime
from typing import Iterable

from models import Candidate


ALLOWED_LABELS = {"KEEP", "REVIEW", "LIKELY_DELETE"}


def _extract_json(text: str):
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"(\[[\s\S]*\]|\{[\s\S]*\})", text)
        if not match:
            raise
        return json.loads(match.group(1))


def advise_candidates(
    candidates: list[Candidate],
    api_key: str = "",
    model: str = "gpt-4.1-mini",
    batch_size: int = 40,
) -> None:
    """
    ファイル本文は送らず、相対パス・拡張子・サイズ・更新日・ルール判定だけを送る。
    結果は Candidate.ai_label / ai_reason に反映する。
    """
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError(
            "openai パッケージが未インストールです。setup_windows.batを実行してください。"
        ) from exc

    key = api_key.strip() or os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("OpenAI APIキーが設定されていません。")

    client = OpenAI(api_key=key)

    for start in range(0, len(candidates), batch_size):
        batch = candidates[start:start + batch_size]
        payload = []
        for index, c in enumerate(batch):
            payload.append({
                "id": start + index,
                "relative_path": c.relative_path,
                "kind": c.kind,
                "extension": c.path.suffix.lower(),
                "size_bytes": c.size_bytes,
                "modified_at": datetime.fromtimestamp(c.modified_ts).isoformat(
                    timespec="seconds"
                ),
                "rule_score": c.score,
                "rule_reasons": c.reasons,
            })

        prompt = f"""
あなたはWindowsデスクトップ整理の安全重視アドバイザーです。
以下は削除候補のメタ情報です。ファイル本文や内容は与えられていません。

各項目について、次のラベルのどれかを返してください。
- KEEP: 残す可能性が高い
- REVIEW: 人が確認して判断
- LIKELY_DELETE: 削除候補フォルダへ退避してよさそう

絶対に、古いという理由だけで重要書類・写真・動画・仕事資料を
LIKELY_DELETEにしないでください。
Office文書、PDF、画像、動画、ソースコード、データベースは原則REVIEWまたはKEEP。
一時ファイル、0バイト、明確な重複、古いインストーラー／圧縮ファイルは
LIKELY_DELETEになり得ます。

JSON配列だけを返してください。説明文やMarkdownは不要です。
形式:
[
  {{"id": 0, "label": "REVIEW", "reason": "短い日本語の理由"}}
]

対象データ:
{json.dumps(payload, ensure_ascii=False)}
""".strip()

        response = client.responses.create(
            model=model,
            input=prompt,
        )
        data = _extract_json(response.output_text)
        if isinstance(data, dict):
            data = data.get("items", [])

        by_id = {
            int(item["id"]): item
            for item in data
            if isinstance(item, dict) and "id" in item
        }

        for index, c in enumerate(batch):
            item = by_id.get(start + index, {})
            label = str(item.get("label", "REVIEW")).upper()
            if label not in ALLOWED_LABELS:
                label = "REVIEW"
            c.ai_label = label
            c.ai_reason = str(item.get("reason", "")).strip()[:200]
