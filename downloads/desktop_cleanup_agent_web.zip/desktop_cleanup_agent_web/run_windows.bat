@echo off
setlocal
cd /d "%~dp0"

set "PYTHONHOME="
set "PYTHONPATH="
set "LOG=%~dp0startup_log.txt"

> "%LOG%" echo ==========================================
>> "%LOG%" echo Desktop Cleanup Agent startup log
>> "%LOG%" echo Date: %date% %time%
>> "%LOG%" echo Folder: %cd%
>> "%LOG%" echo ==========================================

echo.
echo Starting Desktop Cleanup Agent...
echo The app will open in your web browser.
echo Keep this window open while using the app.
echo.

if not exist "%~dp0web_app.py" (
    echo ERROR: web_app.py was not found.
    echo Run this file inside the extracted desktop_cleanup_agent_web folder.
    pause
    exit /b 1
)

if not exist "%~dp0.venv\Scripts\python.exe" (
    call "%~dp0setup_windows.bat"
)

if not exist "%~dp0.venv\Scripts\python.exe" (
    echo ERROR: Python virtual environment was not created.
    pause
    exit /b 1
)

"%~dp0.venv\Scripts\python.exe" "%~dp0web_app.py" >> "%LOG%" 2>&1
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo ERROR: The application stopped. Exit code: %EXITCODE%
    echo.
    type "%LOG%"
    pause
    exit /b %EXITCODE%
)

echo.
echo Application closed normally.
pause
