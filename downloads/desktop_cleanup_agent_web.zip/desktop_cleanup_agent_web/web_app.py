from __future__ import annotations

import csv
import io
import os
import secrets
import subprocess
import threading
import webbrowser
from datetime import datetime
from pathlib import Path

from flask import (
    Flask,
    Response,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from ai_advisor import advise_candidates
from models import Candidate
from organizer import find_latest_quarantine, move_to_quarantine, restore_quarantine
from scanner import scan_folder


app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

CSRF_TOKEN = secrets.token_urlsafe(32)
STATE: dict[str, object] = {
    "root": Path.home() / "Desktop",
    "candidates": [],
    "settings": {
        "old_days": 180,
        "large_mb": 500,
        "min_score": 20,
        "duplicates": True,
    },
}


def format_size(size: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{value:.0f} {unit}"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def check_csrf() -> None:
    if request.form.get("csrf_token", "") != CSRF_TOKEN:
        raise PermissionError("画面の有効期限が切れました。ページを再読み込みしてください。")


def current_root() -> Path:
    root = STATE.get("root", Path.home() / "Desktop")
    return Path(root).expanduser().resolve()


def current_candidates() -> list[Candidate]:
    value = STATE.get("candidates", [])
    return value if isinstance(value, list) else []



@app.template_filter("datetimeformat")
def datetimeformat(value: float) -> str:
    return datetime.fromtimestamp(value).strftime("%Y-%m-%d %H:%M")


@app.context_processor
def inject_globals():
    return {
        "csrf_token": CSRF_TOKEN,
        "format_size": format_size,
        "ai_label_ja": {
            "": "",
            "KEEP": "残す",
            "REVIEW": "要確認",
            "LIKELY_DELETE": "退避候補",
        },
    }


@app.get("/")
def index():
    root = current_root()
    candidates = current_candidates()
    settings = STATE["settings"]
    return render_template(
        "index.html",
        root=str(root),
        candidates=candidates,
        settings=settings,
        api_model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
    )


@app.post("/scan")
def scan():
    try:
        check_csrf()
        root_text = request.form.get("root", "").strip()
        root = Path(root_text).expanduser().resolve()
        if not root.exists() or not root.is_dir():
            flash("存在するフォルダを指定してください。", "error")
            return redirect(url_for("index"))

        old_days = max(1, int(request.form.get("old_days", "180")))
        large_mb = max(1, int(request.form.get("large_mb", "500")))
        min_score = max(0, min(100, int(request.form.get("min_score", "20"))))
        duplicates = request.form.get("duplicates") == "on"

        candidates = scan_folder(
            root=root,
            old_days=old_days,
            large_mb=large_mb,
            min_score=min_score,
            include_duplicates=duplicates,
        )

        STATE["root"] = root
        STATE["candidates"] = candidates
        STATE["settings"] = {
            "old_days": old_days,
            "large_mb": large_mb,
            "min_score": min_score,
            "duplicates": duplicates,
        }
        flash(f"{len(candidates)}件の候補が見つかりました。", "success")
    except Exception as exc:
        flash(f"走査中にエラーが発生しました: {exc}", "error")
    return redirect(url_for("index"))


@app.post("/ai")
def ai_check():
    try:
        check_csrf()
        candidates = current_candidates()
        if not candidates:
            flash("先に候補を探してください。", "error")
            return redirect(url_for("index"))

        api_key = request.form.get("api_key", "").strip()
        model = request.form.get("model", "").strip() or "gpt-4.1-mini"
        advise_candidates(candidates, api_key=api_key, model=model)
        flash("OpenAI APIによる補助判定が完了しました。", "success")
    except Exception as exc:
        flash(f"AI判定中にエラーが発生しました: {exc}", "error")
    return redirect(url_for("index"))


@app.post("/move")
def move_selected():
    try:
        check_csrf()
        candidates = current_candidates()
        indexes = request.form.getlist("selected")
        selected: list[Candidate] = []

        for raw in indexes:
            try:
                idx = int(raw)
                if 0 <= idx < len(candidates):
                    selected.append(candidates[idx])
            except ValueError:
                continue

        if not selected:
            flash("移動する項目を選択してください。", "error")
            return redirect(url_for("index"))

        quarantine, records = move_to_quarantine(selected, current_root())
        moved_count = sum(1 for item in records if item.get("status") == "moved")
        error_count = sum(1 for item in records if item.get("status") == "error")

        STATE["candidates"] = [
            candidate for candidate in candidates
            if candidate not in selected or candidate.path.exists()
        ]

        flash(
            f"{moved_count}件を削除候補フォルダへ移動しました。"
            f" エラー: {error_count}件。移動先: {quarantine}",
            "success",
        )
    except Exception as exc:
        flash(f"移動中にエラーが発生しました: {exc}", "error")
    return redirect(url_for("index"))


@app.post("/restore")
def restore():
    try:
        check_csrf()
        latest = find_latest_quarantine(current_root())
        if latest is None:
            flash("復元できる削除候補フォルダが見つかりません。", "error")
            return redirect(url_for("index"))

        restored, errors = restore_quarantine(latest)
        STATE["candidates"] = []
        flash(
            f"{restored}件を元の場所へ戻しました。"
            f" 復元できなかった項目: {len(errors)}件。",
            "success" if not errors else "error",
        )
    except Exception as exc:
        flash(f"復元中にエラーが発生しました: {exc}", "error")
    return redirect(url_for("index"))


@app.post("/open")
def open_item():
    try:
        check_csrf()
        idx = int(request.form.get("index", "-1"))
        candidates = current_candidates()
        if not 0 <= idx < len(candidates):
            raise ValueError("項目が見つかりません。")

        path = candidates[idx].path
        if path.is_file():
            subprocess.Popen(["explorer", "/select,", str(path)])
        else:
            os.startfile(str(path))  # type: ignore[attr-defined]
    except Exception as exc:
        flash(f"エクスプローラーを開けませんでした: {exc}", "error")
    return redirect(url_for("index"))


@app.get("/export.csv")
def export_csv():
    candidates = current_candidates()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "スコア",
        "AI判定",
        "種類",
        "サイズ(bytes)",
        "更新日",
        "候補理由",
        "AI理由",
        "相対パス",
        "絶対パス",
    ])

    ai_label_ja = {
        "": "",
        "KEEP": "残す",
        "REVIEW": "要確認",
        "LIKELY_DELETE": "退避候補",
    }

    for candidate in candidates:
        writer.writerow([
            candidate.score,
            ai_label_ja.get(candidate.ai_label, candidate.ai_label),
            candidate.kind,
            candidate.size_bytes,
            datetime.fromtimestamp(candidate.modified_ts).isoformat(timespec="seconds"),
            " / ".join(candidate.reasons),
            candidate.ai_reason,
            candidate.relative_path,
            str(candidate.path),
        ])

    filename = f"delete_candidates_{datetime.now():%Y%m%d_%H%M%S}.csv"
    return Response(
        output.getvalue().encode("utf-8-sig"),
        mimetype="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def open_browser() -> None:
    webbrowser.open("http://127.0.0.1:8765/")


if __name__ == "__main__":
    print("Desktop Cleanup Agent is running.")
    print("Open: http://127.0.0.1:8765/")
    print("Close this command window to stop the app.")
    threading.Timer(1.2, open_browser).start()
    app.run(
        host="127.0.0.1",
        port=8765,
        debug=False,
        use_reloader=False,
        threaded=True,
    )
