from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal


CandidateKind = Literal["file", "folder"]


@dataclass
class Candidate:
    path: Path
    root: Path
    kind: CandidateKind
    size_bytes: int
    modified_ts: float
    score: int = 0
    reasons: list[str] = field(default_factory=list)
    ai_label: str = ""
    ai_reason: str = ""

    @property
    def relative_path(self) -> str:
        try:
            return str(self.path.relative_to(self.root))
        except ValueError:
            return str(self.path)

    def add_reason(self, score: int, reason: str) -> None:
        self.score = min(100, self.score + score)
        if reason not in self.reasons:
            self.reasons.append(reason)
