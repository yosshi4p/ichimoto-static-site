from __future__ import annotations

import hashlib
import os
import re
import stat
import time
from collections import defaultdict
from pathlib import Path
from typing import Callable

from models import Candidate


TEMP_EXTENSIONS = {
    ".tmp", ".temp", ".bak", ".old", ".dmp", ".chk", ".crdownload",
    ".part", ".download", ".partial", ".cache",
}
INSTALLER_ARCHIVE_EXTENSIONS = {
    ".exe", ".msi", ".msix", ".zip", ".7z", ".rar", ".iso",
}
LOG_EXTENSIONS = {".log"}
COPY_NAME_PATTERNS = [
    re.compile(r"\s-\sコピー(?:\s*\(\d+\))?$", re.IGNORECASE),
    re.compile(r"\sコピー(?:\s*\(\d+\))?$", re.IGNORECASE),
    re.compile(r"\scopy(?:\s*\(\d+\))?$", re.IGNORECASE),
    re.compile(r"\s\(\d+\)$"),
    re.compile(r"_copy\d*$", re.IGNORECASE),
]


def _is_hidden_or_system(path: Path) -> bool:
    """Windowsの隠し・システム属性、またはドット始まりを除外する。"""
    if path.name.startswith("."):
        return True

    try:
        attrs = path.stat(follow_symlinks=False).st_file_attributes
        hidden = getattr(stat, "FILE_ATTRIBUTE_HIDDEN", 0x2)
        system = getattr(stat, "FILE_ATTRIBUTE_SYSTEM", 0x4)
        return bool(attrs & (hidden | system))
    except (AttributeError, OSError):
        return False


def _safe_stat(path: Path):
    try:
        return path.stat(follow_symlinks=False)
    except (OSError, PermissionError):
        return None


def _sha256(path: Path, chunk_size: int = 1024 * 1024) -> str | None:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as f:
            while chunk := f.read(chunk_size):
                digest.update(chunk)
        return digest.hexdigest()
    except (OSError, PermissionError):
        return None


def _looks_like_copy(path: Path) -> bool:
    stem = path.stem
    return any(pattern.search(stem) for pattern in COPY_NAME_PATTERNS)


def _is_under(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except (OSError, ValueError):
        return False


def scan_folder(
    root: Path,
    old_days: int = 180,
    large_mb: int = 500,
    min_score: int = 20,
    include_duplicates: bool = True,
    progress: Callable[[str], None] | None = None,
) -> list[Candidate]:
    root = root.expanduser().resolve()
    now = time.time()
    old_seconds = max(1, old_days) * 86400
    large_bytes = max(1, large_mb) * 1024 * 1024

    quarantine_prefix = "_削除候補_"
    files: list[Candidate] = []
    empty_folders: list[Candidate] = []

    if progress:
        progress("フォルダを走査しています…")

    for current, dirs, names in os.walk(root, topdown=True, followlinks=False):
        current_path = Path(current)

        # 退避済みフォルダ、隠し・システム、シンボリックリンクを除外
        filtered_dirs: list[str] = []
        for dirname in dirs:
            p = current_path / dirname
            if dirname.startswith(quarantine_prefix):
                continue
            if p.is_symlink() or _is_hidden_or_system(p):
                continue
            filtered_dirs.append(dirname)
        dirs[:] = filtered_dirs

        visible_files = []
        for name in names:
            path = current_path / name
            if path.is_symlink() or _is_hidden_or_system(path):
                continue
            visible_files.append(path)

        # 中に見えるファイルもサブフォルダもなければ空フォルダ候補
        if current_path != root and not dirs and not visible_files:
            st = _safe_stat(current_path)
            if st:
                c = Candidate(
                    path=current_path,
                    root=root,
                    kind="folder",
                    size_bytes=0,
                    modified_ts=st.st_mtime,
                )
                c.add_reason(85, "空のフォルダ")
                empty_folders.append(c)

        for path in visible_files:
            st = _safe_stat(path)
            if not st:
                continue

            c = Candidate(
                path=path,
                root=root,
                kind="file",
                size_bytes=st.st_size,
                modified_ts=st.st_mtime,
            )
            ext = path.suffix.lower()
            age_seconds = now - st.st_mtime

            if path.name.startswith("~$"):
                c.add_reason(95, "Officeの一時ファイルらしい名前")

            if st.st_size == 0:
                c.add_reason(90, "0バイトの空ファイル")

            if ext in TEMP_EXTENSIONS:
                c.add_reason(70, f"一時・バックアップ系の拡張子（{ext}）")

            if ext in LOG_EXTENSIONS and age_seconds >= old_seconds:
                c.add_reason(55, f"{old_days}日以上前のログファイル")

            if age_seconds >= old_seconds:
                c.add_reason(15, f"{old_days}日以上更新されていない")

            if st.st_size >= large_bytes:
                c.add_reason(25, f"{large_mb}MB以上の大きなファイル")

            if ext in INSTALLER_ARCHIVE_EXTENSIONS and age_seconds >= old_seconds:
                c.add_reason(35, "古いインストーラー／圧縮ファイル")

            if _looks_like_copy(path):
                c.add_reason(30, "コピーや連番ファイルらしい名前")

            files.append(c)

    # 完全一致の重複ファイル。最新の1件は残し、それ以外を候補にする。
    if include_duplicates:
        if progress:
            progress("同じサイズのファイルから重複を確認しています…")

        by_size: dict[int, list[Candidate]] = defaultdict(list)
        for c in files:
            if c.size_bytes > 0:
                by_size[c.size_bytes].append(c)

        for same_size in by_size.values():
            if len(same_size) < 2:
                continue

            by_hash: dict[str, list[Candidate]] = defaultdict(list)
            for c in same_size:
                file_hash = _sha256(c.path)
                if file_hash:
                    by_hash[file_hash].append(c)

            for same_hash in by_hash.values():
                if len(same_hash) < 2:
                    continue
                same_hash.sort(key=lambda item: item.modified_ts, reverse=True)
                kept = same_hash[0]
                for duplicate in same_hash[1:]:
                    duplicate.add_reason(
                        80,
                        f"内容が完全に同じ重複ファイル（残す候補: {kept.relative_path}）",
                    )

    candidates = [
        c for c in files + empty_folders
        if c.score >= min_score
    ]
    candidates.sort(key=lambda c: (-c.score, c.kind, c.relative_path.lower()))

    if progress:
        progress(f"{len(candidates)}件の候補が見つかりました。")
    return candidates
