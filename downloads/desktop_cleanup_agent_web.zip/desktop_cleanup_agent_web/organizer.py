from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

from models import Candidate


MANIFEST_NAME = "_移動履歴.json"


def _unique_destination(path: Path) -> Path:
    if not path.exists():
        return path

    counter = 2
    stem = path.stem
    suffix = path.suffix
    while True:
        candidate = path.with_name(f"{stem}_{counter}{suffix}")
        if not candidate.exists():
            return candidate
        counter += 1


def move_to_quarantine(
    candidates: list[Candidate],
    root: Path,
) -> tuple[Path, list[dict]]:
    root = root.expanduser().resolve()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    quarantine = root / f"_削除候補_{timestamp}"
    quarantine.mkdir(parents=True, exist_ok=False)

    records: list[dict] = []

    # ファイルを先に移動し、空フォルダは深い階層から処理する
    ordered = sorted(
        candidates,
        key=lambda c: (c.kind == "folder", -len(c.path.parts)),
    )

    for candidate in ordered:
        source = candidate.path
        if not source.exists():
            continue

        try:
            relative = source.resolve().relative_to(root)
        except ValueError:
            continue

        destination = _unique_destination(quarantine / relative)
        destination.parent.mkdir(parents=True, exist_ok=True)

        try:
            shutil.move(str(source), str(destination))
        except (OSError, PermissionError) as exc:
            records.append({
                "status": "error",
                "original_path": str(source),
                "moved_path": "",
                "kind": candidate.kind,
                "score": candidate.score,
                "reasons": candidate.reasons,
                "error": str(exc),
            })
            continue

        records.append({
            "status": "moved",
            "original_path": str(source),
            "moved_path": str(destination),
            "kind": candidate.kind,
            "score": candidate.score,
            "reasons": candidate.reasons,
            "ai_label": candidate.ai_label,
            "ai_reason": candidate.ai_reason,
            "moved_at": datetime.now().isoformat(timespec="seconds"),
        })

    manifest = {
        "root": str(root),
        "quarantine": str(quarantine),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "records": records,
    }
    (quarantine / MANIFEST_NAME).write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return quarantine, records


def find_latest_quarantine(root: Path) -> Path | None:
    root = root.expanduser().resolve()
    folders = [
        p for p in root.glob("_削除候補_*")
        if p.is_dir() and (p / MANIFEST_NAME).exists()
    ]
    return max(folders, key=lambda p: p.name, default=None)


def restore_quarantine(quarantine: Path) -> tuple[int, list[str]]:
    manifest_path = quarantine / MANIFEST_NAME
    if not manifest_path.exists():
        raise FileNotFoundError("移動履歴ファイルが見つかりません。")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    restored = 0
    errors: list[str] = []

    records = manifest.get("records", [])
    # 深い場所から復元すると、フォルダ競合を避けやすい
    records = sorted(
        records,
        key=lambda r: len(Path(r.get("original_path", "")).parts),
    )

    for record in records:
        if record.get("status") != "moved":
            continue

        moved = Path(record["moved_path"])
        original = Path(record["original_path"])

        if not moved.exists():
            continue
        if original.exists():
            errors.append(f"復元先が既に存在します: {original}")
            continue

        try:
            original.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(moved), str(original))
            restored += 1
        except (OSError, PermissionError) as exc:
            errors.append(f"{original}: {exc}")

    return restored, errors
