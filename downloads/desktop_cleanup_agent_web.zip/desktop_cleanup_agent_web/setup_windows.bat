@echo off
setlocal
cd /d "%~dp0"

set "PYTHONHOME="
set "PYTHONPATH="

echo ==========================================
echo Desktop Cleanup Agent - Initial Setup
echo ==========================================

where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python launcher "py" was not found.
    echo Install Python 3.10 or later and run this file again.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating Python virtual environment...
    py -m venv .venv
    if errorlevel 1 goto :error
)

echo Updating pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error

echo Installing required packages...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo Setup completed successfully.
echo Double-click run_windows.bat to start the app.
pause
exit /b 0

:error
echo.
echo ERROR: Setup failed.
pause
exit /b 1
